package training.properties;

/*
 * 
 * Define all necessary connection parameters for other classes here
 * 
 */

public class Properties
{	
	public static String agent_id="d4f1ae32-61c0-487f-8743-8da23c3eea1f";
	public static String agent_credentials ="{tOu;uS280}7r,HF8,Zh/k*=";
		
	public static String jmsurl = "failover:(ssl://stg001eu1-msgbus.3dexperience.3ds.com:61617,ssl://stg001eu1-msgbus-1.3dexperience.3ds.com:61617)?randomize=false&nested.soTimeout=60000&nested.soWriteTimeout=60000";
	
	public static String tenantid ="OI000399516";
	
	public static String sec_context = "ctx::VPLMProjectLeader.Company Name.Common Space";
		
	public static String passport3ds_url_str = "https://oi000399516-eu1.iam.3dexperience.3ds.com";
	
	public static String space3ds_url_str = "https://oi000399516-eu1-space.3dexperience.3ds.com/enovia" ;
		
	public static String exchange_url_str = "https://oi000399516-eu1-exchange.3dexperience.3ds.com/exchange" ;
	
}