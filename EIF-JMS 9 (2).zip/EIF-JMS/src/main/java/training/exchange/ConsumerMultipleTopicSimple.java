package training.exchange;

import java.net.URISyntaxException;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

import org.apache.activemq.ActiveMQConnection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import training.exchange.util.EID_service;
import training.properties.Properties;

public class ConsumerMultipleTopicSimple
{
	
	public static String url = Properties.jmsurl;
	public static String tenantid =Properties.tenantid;
	public static String agent_id=Properties.agent_id;
	public static String agent_credentials =Properties.agent_credentials;
	
	public static void startListener() throws JMSException, URISyntaxException
	{
		System.out.println("Start");
		
		ActiveMQConnection connection = ActiveMQConnection.makeConnection(agent_id,agent_credentials,url);
		
		// need to setClientID value, any string value you wish
        connection.setClientID("Ajai");
        
        try
        {
        	connection.start();
        }
        catch(Exception e)
        {
            System.err.println("NOT CONNECTED!!!");
        }
        
        Session session = connection.createSession(false,Session.AUTO_ACKNOWLEDGE);
        
        System.out.println("----------------------------------------");
        System.out.println("Subscribing to following topics new:");
       
        //String topicname_user ="3dsevents." + tenantid +".3dspace.user";
        String topicname_user ="3dsevents." + tenantid +".3DSpace.user";
        System.out.println(topicname_user);
        Topic topic_user = session.createTopic(topicname_user);
        
        MessageConsumer consumer_user = session.createDurableSubscriber(topic_user,"Events_Durable_Subscriber_3dspace_user_01");
        
       //topic 3dsevents.$tenant.3dspace.user
        MessageListener listener_user = new MessageListener()
        {
            public void onMessage(Message message)
            {
                try {
                    if (message instanceof TextMessage)
                    {
                        TextMessage textMessage = (TextMessage) message;
                        System.out.println("\nReceived message from topic NEW " + topicname_user  + ":\n" + textMessage.getText() ); 
                        JSONParser parser = new JSONParser();
                        String json_stream =textMessage.getText().toString();
                        try {

	                        JSONObject jsonObject = (JSONObject) parser.parse(json_stream);
	
	                        JSONParser dataparser = new JSONParser();
	                        JSONObject datajson = (JSONObject) dataparser.parse(jsonObject.get("data").toString());
	                        String user= datajson.get("user").toString();
	                        String eventType = datajson.get("eventType").toString();
	
	                        JSONParser subjectparser= new JSONParser();
	                        JSONObject subjectjson = (JSONObject) subjectparser.parse(datajson.get("subject").toString());
	                        String type= subjectjson.get("type").toString();
	                        String id = subjectjson.get("identifier").toString();
	
	                        System.out.println("user: " + user);
	                        System.out.println("eventType: " + eventType);
	                        System.out.println("type: " + type);
	                        System.out.println("id:" +id);
	                      //React only for event from a specific user, of a specific type and object type
	                        /*if (user.equalsIgnoreCase("akajaikumar")//ypur username
	                        && type.equalsIgnoreCase("VPMReference")
	                        && eventType.equalsIgnoreCase("created"))*/
	                        if (//ypur username
	    	                        type.equalsIgnoreCase("VPMReference")
	    	                        && eventType.equalsIgnoreCase("created"))
	                        {
	                        	System.out.println("Fetch more detailed information for EID " + id );
	                        }
	                        //Check if Enterprise partnumber is already set, if not call REST service to set it
	                        //read properties of EID and check for dseng: EnterpriseReference partnumber attribute
	                        //if not set populate it
	                        EID_service eid = new EID_service(id);
	                        eid.prepareAuthorizationHeaderValue();
	                        String sjson = eid.get_properties();

	                        System.out.println("\n" + sjson);
	                        
	                        JSONParser eid_parser = new JSONParser();
	                        JSONObject eid_jsonObject = (JSONObject) eid_parser.parse(sjson);
	                        JSONArray member_array = (JSONArray) eid_jsonObject.get("member");
	                        JSONObject jsonobject = (JSONObject) member_array.get(0);

	                        String name =jsonobject.get("name").toString();
	                        String revision = jsonobject.get("revision").toString();

	                        JSONObject EnterpriseReference_json =(JSONObject) jsonobject.get("dseng:EnterpriseReference");
	                        String partNumber =EnterpriseReference_json.get("partNumber") .toString();

	                        System.out.println("name:" + name);
	                        System.out.println("revision:" + revision);
	                        System.out.println("partNumber:" + partNumber);

	                        if(partNumber.equalsIgnoreCase("") || partNumber.equalsIgnoreCase(null))
	                        {
		                        System.out.println("Set the Enterprise partnumber of the EID " + name +" " + revision );
		                        //get the current number from the name attribute without leading zeros
		                        String snumber=name.substring(name.lastIndexOf("-")+1, name.length());
		                        snumber = snumber.replaceFirst("^0+( ?! $)", "");
		                        eid.set_enterprisenumber("ERP-" + snumber);

	                        }
	                        else
	                        {
	                        	System.out.println("Enterprise partNumber of EID " + name +" " + revision +" is already set to " + partNumber);
	                        }

                        } catch (ParseException e) {

                        	e.printStackTrace();
                        }
                    }
                    else
                    {
                    	System.out.println("No text-message");
                    }
                } 
                catch (Exception e)
                {
                    System.out.println("Caught:" + e);
                    e.printStackTrace();
                }
            }
        };
        
        consumer_user.setMessageListener(listener_user);
	}
}
