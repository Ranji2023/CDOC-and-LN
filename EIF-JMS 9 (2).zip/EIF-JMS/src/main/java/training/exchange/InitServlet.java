package training.exchange;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

public class InitServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        System.out.println("######## INIT SERVLET START ########");

        try {
            ConsumerMultipleTopicSimple.startListener();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}