package training.exchange;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class JMSStartupListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
    	 System.out.println("######## LISTENER STARTED ########");

        try {
            ConsumerMultipleTopicSimple.startListener();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Stopping JMS Listener...");
    }
}