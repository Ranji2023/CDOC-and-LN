package training.exchange.util;


import java.io.UnsupportedEncodingException;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.URI;
//import java.net.CookieHandler;
//import java.net.CookieManager;
//import java.net.CookieStore;
//import java.net.HttpCookie;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;


import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import training.properties.Properties;




public class EID_service
{
		public static String agent_id=Properties.agent_id;
		public static String agent_credentials=Properties.agent_credentials;
		
		public static String _sec_context=Properties.sec_context;
		
		public static String _tenant=Properties.tenantid;
		public static String _passport3ds_url_str=Properties.passport3ds_url_str;
		public static String _space3ds_url_str=Properties.space3ds_url_str;
				
		public static String _csrf_token_url=_space3ds_url_str +"/resources/v1/application/CSRF" + "?tenant=" + _tenant;
		public static String _csrf_token="";
		
		//public static CookieManager cookieManager = new CookieManager();
		
		public static String _basicauthentication="";
		
		//to be changed for each exchange job
		public String physicalid=null;	//physicalid of the EID 
		
		public static HttpClient httpClient=null;
				
		
		public EID_service (String id)
		{
			physicalid=id;
			
			//HTTPClient
			httpClient = HttpClient.newBuilder()
			.cookieHandler(new CookieManager(null, CookiePolicy.ACCEPT_ALL))
			.followRedirects(HttpClient.Redirect.ALWAYS)
			.build();
		}
		
		public EID_service ()
		{
		
			//HTTPClient
			httpClient = HttpClient.newBuilder()
			.cookieHandler(new CookieManager(null, CookiePolicy.ACCEPT_ALL))
			.followRedirects(HttpClient.Redirect.ALWAYS)
			.build();
		}
		
	    @SuppressWarnings({ "serial" })
		public String get_properties() throws Exception
		{
			/////////////////////////
			//get_properties
			////////////////////////
			String _targetURL_1 = _space3ds_url_str + "/" + "resources/v1/modeler/dseng/dseng:EngItem/" + physicalid + "?$mask=dsmveng:EngItemMask.Details" +"&tenant=" + _tenant ;			
			String _methodType_1 = "GET";
			String _requestBody_1 = "";
			String _content_type_1 ="application/json";
			
			//_csrf_token=get_csrf_token();

			HashMap<String, String> HeaderProperties_1 =  new HashMap<String, String>()
			{
				{
					put("Authorization",_basicauthentication);
					put("SecurityContext", _sec_context);
					
					//put("ENO_CSRF_TOKEN", _csrf_token);
					
				}
			};
			
						
			HttpResponse<String> response  = load_url(httpClient,  _methodType_1,  _content_type_1,  _requestBody_1,  _targetURL_1,HeaderProperties_1);


			System.out.println("_response_1:" + response.body());
			
			return response.body();
			
			
		}
		
	    @SuppressWarnings({ "unused", "serial" })		
		public void set_enterprisenumber(String number) throws Exception
		{
			//////////////////////////
			//set_enterprisenumber
			//////////////////////////
			String _targetURL_2 = _space3ds_url_str + "/" + "resources/v1/modeler/dseng/dseng:EngItem/" + physicalid +"/dseng:EnterpriseReference"+ "?tenant=" + _tenant ;				
			String _methodType_2 = "POST";
			String _requestBody_2 = "{\"partNumber\":\"" + number +"\"}";

			String _content_type_2 ="application/json";
			_csrf_token=get_csrf_token();

			HashMap<String, String> HeaderProperties_2 =  new HashMap<String, String>()
			{
					{
						put("Accept", "application/json");
						//put("x-requested-with", "batch");
						put("Authorization",_basicauthentication);
						
						put("ENO_CSRF_TOKEN", _csrf_token);
						put("SecurityContext", _sec_context);
					}
			};
			String _response_2=null; 
				
			//System.out.println("_requestBody_2: " + _requestBody_2);
			
			HttpResponse<String> response  = load_url(httpClient,  _methodType_2,  _content_type_2,  _requestBody_2,  _targetURL_2, HeaderProperties_2);

			System.out.println("_response_2:" + response.body());
				
				
		}
		
	    public String prepareAuthorizationHeaderValue() throws UnsupportedEncodingException
		{
			//Basic authentication for openness agent
			String loginandpassword = agent_id + ":" + agent_credentials ;
			String base64encodedString = Base64.getEncoder().encodeToString(loginandpassword.getBytes("utf-8"));
			                
			_basicauthentication = "Basic " +  base64encodedString  ;
			
			System.out.println("_basicauthentication: " + _basicauthentication);
			return _basicauthentication;
		}
	
	
		
	
		@SuppressWarnings("serial")
		static public String get_csrf_token() throws Exception
		{

			// == == == == == == == == == == == == == == == == == == == == == == == == == ==
			// == STEP 3 Create a CSRF Token ==
			// == == == == == == == == == == == == == == == == == == == == == == == == == ==
			
			HashMap<String, String> headers =  new HashMap<String, String>()
			{
				{
					//put("Authorization",_basicauthentication);
					//put("SecurityContext", _sec_context);
				}
			};
					
			HttpResponse<String> response = load_url(httpClient,  "GET",  "",  "",  _csrf_token_url,headers);
			
			
			System.out.println("response: [" + response.body() + "]");
			
			JSONParser parser = new JSONParser();
			
			Object obj = parser.parse(response.body());
			JSONObject json_obj = (JSONObject)obj;
			if(json_obj.get("success").toString().equalsIgnoreCase("true"))
			{
				JSONObject csrf = (JSONObject) json_obj.get("csrf");
				//System.out.println(csrf.toJSONString());
				_csrf_token=csrf.get("value").toString();
				
			}
		   
			//System.out.println(_csrf_token);
			return _csrf_token;
		}
		
		static public HttpResponse<String> load_url(HttpClient client, String method, String content_type, String post_data, String sURL,HashMap<String,String> headers) throws Exception
		{
			
			HttpRequest.Builder requestbuilder = HttpRequest.newBuilder()
	                .uri(URI.create(sURL))
	                .method(method, HttpRequest.BodyPublishers.ofString(post_data.toString()))
	                .setHeader("Content-Type",content_type) 
					.setHeader("Accept","application/json") ;
	                
			for (Map.Entry<String, String> entry : headers.entrySet())
			{
			    //System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
			    requestbuilder.setHeader(entry.getKey(),entry.getValue());
				
			}
			
			
			HttpRequest request = requestbuilder.build();
			
			HttpResponse<String> response = client.send(request,HttpResponse.BodyHandlers.ofString());

		    //System.out.println(response.body());
			System.out.println("connection url [" + sURL +"] " + response.statusCode());
			

			
			return response;
		}
		
		@SuppressWarnings({ "serial", "unused" })
		static public void logout_passport() throws Exception
		{
			String strLogout = _passport3ds_url_str + "/logout";
			
			HashMap<String, String> headers =  new HashMap<String, String>()
			{
				{
					
				}
			};
			
			HttpResponse<String> response = load_url(httpClient,  "GET",  "",  "",  strLogout,headers);
		
		}

	}


